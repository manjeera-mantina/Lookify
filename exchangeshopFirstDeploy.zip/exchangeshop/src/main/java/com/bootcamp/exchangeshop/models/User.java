package com.bootcamp.exchangeshop.models;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="users")
public class User {
			    
		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Long id;
		    
		    @NotEmpty(message="Username is required!")
		    @Size(min=3, max=30, message="Username must be atleast 3 characters")
		    private String userName;
		    
		    @NotEmpty(message="Email is required!")
		    @Email(message="Please enter a valid email!")
		    private String email;
		    
		    @NotEmpty(message="Password is required!")
		    @Size(min=8, max=128, message="Password must be atleast 8 characters")
		    private String password;
		    
		    @Transient
		 
		    @Size(min=8, max=128, message="Confirm Password must be atleast 8 characters")
		    private String confirm;
		    
		    @NotNull(message="Answer is required!")
		    private Boolean willProvideFeedback;
		    
		    @OneToOne(mappedBy="resident", fetch=FetchType.LAZY)
		    private Address address;
		  
		    @OneToMany(mappedBy="postor", fetch = FetchType.LAZY)
		    private List<Product> userPosts;
		    
		    @OneToMany(mappedBy="purchasor", fetch = FetchType.LAZY)
		    private List<Purchase> userPurchases;
		    
		    private Integer sellerRating;


		    @PrePersist
		    protected void onCreate(){
		        this.createdAt = new Date();
		    }
		    @PreUpdate
		    protected void onUpdate(){
		        this.updatedAt = new Date();
		    }
		    
		 // This will not allow the createdAt column to be updated after creation
		    @Column(updatable=false)
		    @DateTimeFormat(pattern="yyyy-MM-dd")
		    private Date createdAt;
		    @DateTimeFormat(pattern="yyyy-MM-dd")
		    private Date updatedAt;
		    
		    public User () {}

			public User(
					String email,
					String password,
					String confirm) {
				super();
				this.email = email;
				this.password = password;
				this.confirm = confirm;
			}

			public User(
					String userName,
					Address address,
					List<Product> userPosts,
					List<Purchase> userPurchases, Boolean willProvideFeedback){
				super();
				this.userName = userName;
				this.address = address;
				this.userPosts = userPosts;
				this.userPurchases = userPurchases;
				this.willProvideFeedback = willProvideFeedback;
			}

			public Long getId() {
				return id;
			}

			public void setId(Long id) {
				this.id = id;
			}

			public String getUserName() {
				return userName;
			}
			public void setUserName(String userName) {
				this.userName = userName;
			}
			public String getEmail() {
				return email;
			}
			public void setEmail(String email) {
				this.email = email;
			}
			public String getPassword() {
				return password;
			}
			public void setPassword(String password) {
				this.password = password;
			}
			public String getConfirm() {
				return confirm;
			}
			public void setConfirm(String confirm) {
				this.confirm = confirm;
			}
			public Address getAddress() {
				return address;
			}
			public void setAddress(Address address) {
				this.address = address;
			}
			public List<Product> getUserPosts() {
				return userPosts;
			}
			public void setUserPosts(List<Product> userPosts) {
				this.userPosts = userPosts;
			}
			public List<Purchase> getUserPurchases() {
				return userPurchases;
			}
			public void setUserPurchases(List<Purchase> userPurchases) {
				this.userPurchases = userPurchases;
			}
			public Integer getSellerRating() {
			return sellerRating;
			}
			public void setSellerRating(Integer sellerRating) {
			this.sellerRating = sellerRating;
			}
		
			public Boolean getWillProvideFeedback() {
				return willProvideFeedback;
			}
			public void setWillProvideFeedback(Boolean willProvideFeedback) {
				this.willProvideFeedback = willProvideFeedback;
			}
			public Date getCreatedAt() {
				return createdAt;
			}

			public void setCreatedAt(Date createdAt) {
				this.createdAt = createdAt;
			}

			public Date getUpdatedAt() {
				return updatedAt;
			}

			public void setUpdatedAt(Date updatedAt) {
				this.updatedAt = updatedAt;
			}
		    
}
