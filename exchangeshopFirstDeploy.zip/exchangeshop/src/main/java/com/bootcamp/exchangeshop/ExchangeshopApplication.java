package com.bootcamp.exchangeshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExchangeshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExchangeshopApplication.class, args);
	}

}
